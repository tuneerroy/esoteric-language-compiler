import Test.HUnit
import Test.QuickCheck

import Lib

main :: IO ()
main = do 
    putStrLn someFunc
    putStrLn "Test suite not yet implemented"
