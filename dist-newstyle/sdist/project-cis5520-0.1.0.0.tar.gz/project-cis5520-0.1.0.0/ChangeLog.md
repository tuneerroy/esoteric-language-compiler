# Changelog for project-cis5520

## 22fa
- Uses lts-19.19
- GHC2021 language + common stanza
