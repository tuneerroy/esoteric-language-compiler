module Main where

import Lib

main :: IO ()
main = return ()

-- data ProgramState = {PC, Store}

-- newtype Program = array

-- MonadState m, ProgramState m => program -> m ()

-- m ()




-- program -> State (Store, PC) ()